window.onload= function() {
    var map = L.map("mapid").setView([48.845,2.424],10) ;
    L.tileLayer(
        'https://wxs.ign.fr/pratique/geoportail/wmts?service=WMTS&request=GetTile&version=1.0.0&tilematrixset=PM&tilematrix={z}&tilecol={x}&tilerow={y}&layer=ORTHOIMAGERY.ORTHOPHOTOS&format=image/jpeg&style=normal',
        {
            minZoom : 0,
            maxZoom : 18,
            tileSize : 256,
            attribution : "IGN-F/Geoportail"
        }).addTo(map);
}



/*
//Exemple de code possible dans le cas où l'on veut aller vers une carte géoportail au click sur la page. 
//Il faut alors enlever les lignes "browser_action" du manifest.
document.onclick = function doSomething(e) {
    let newWin = window.open("about:blank", "hello", "width=400,height=400");
    newWin.onload = function() {
        let html = '<div style="font-size:30px">Welcome!</div>';
        newWin.document.body.insertAdjacentHTML('afterbegin', html);
    };
    //window.open('https://www.geoportail.gouv.fr/carte?c=4.7187738774928105,43.8551805963952&z=14&l0=GEOGRAPHICALGRIDSYSTEMS.MAPS.SCAN25TOUR.CV::GEOPORTAIL:OGC:WMTS(1)&permalink=yes','popup','width=400,height=400,toolbar=no,scrollbars=no,resizable=yes');	
};
*/
